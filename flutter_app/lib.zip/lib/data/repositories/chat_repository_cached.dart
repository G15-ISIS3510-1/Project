import 'dart:convert';
import 'dart:io';

import 'package:drift/drift.dart';
import 'package:flutter_app/app/utils/net.dart';
import 'package:flutter_app/data/database/app_database.dart';
import 'package:flutter_app/data/database/daos/conversations_dao.dart';
import 'package:flutter_app/data/database/daos/messages_dao.dart';

import 'package:flutter_app/data/models/conversation_model.dart';
import 'package:flutter_app/data/models/message_model.dart';
import 'package:flutter_app/data/repositories/chat_repository.dart';
import 'package:flutter_app/data/sources/local/conversation_local_source.dart';
import 'package:flutter_app/data/sources/local/message_local_source.dart';

// (Opcional) para last-read si quieres integrarlo aquí
import 'package:flutter_app/data/prefs/last_read_prefs.dart';
import 'package:http/http.dart';

/// Decorador con cache local (Drift) para ChatRepository.
/// - Respeta tu interfaz existente 1:1.
/// - Usa DAOs directamente para construir Companions (sin depender de toJson/fromJson).
class ChatRepositoryCached implements ChatRepository {
  final ChatRepositoryImpl remote;
  final ConversationLocalSource convLocal;
  final MessageLocalSource msgLocal;

  /// Acceso directo a DAOs para armar Companions sin mappers adicionales
  final ConversationsDao convDao;
  final MessagesDao msgDao;

  /// (Opcional) Preferences para last-read
  final LastReadPrefs? lastReadPrefs;

  final String Function() currentUserId;

  ChatRepositoryCached({
    required this.remote,
    required this.convLocal,
    required this.msgLocal,
    required this.convDao,
    required this.msgDao,
    this.lastReadPrefs,
    required this.currentUserId,
  });

  // --------------------------
  // Conversations
  // --------------------------

  @override
  Future<List<Conversation>> listConversations({
    int skip = 0,
    int limit = 100,
  }) async {
    // 1) Cache inmediato (especialmente cuando skip==0)
    final cached = await convLocal.getPage(
      page: (skip ~/ (limit == 0 ? 1 : limit)) + 1,
      limit: limit,
    );
    final hasCached = cached.isNotEmpty;

    if (hasCached && skip == 0) {
      // Dispara refresh en background y devuelve cache ya
      // ignore: unawaited_futures
      _refreshConversationsInBackground(limit: limit);
      return cached;
    }

    // 2) Si no hay cache (o es una página > 1), intenta red; si falla, recurre a cache
    try {
      final remoteList = await remote.listConversations(
        skip: skip,
        limit: limit,
      );

      // Cachear lo remoto
      await convDao.upsertAll(
        remoteList.map(_conversationToDb).toList(growable: false),
      );
      // (Opcional) checkpoint
      // ignore: unawaited_futures
      convLocal.checkpoint(
        page: (skip ~/ (limit == 0 ? 1 : limit)) + 1,
        limit: limit,
      );

      return remoteList;
    } on SocketException catch (_) {
      // Offline → devuelve cache si hay
      if (hasCached) return cached;
      return const <Conversation>[];
    } on ClientException catch (_) {
      if (hasCached) return cached;
      return const <Conversation>[];
    } catch (_) {
      // Error no esperado → fallback cache si existe
      if (hasCached) return cached;
      rethrow;
    }
  }

  Future<void> _refreshConversationsInBackground({required int limit}) async {
    if (!await Net.isOnline()) return;
    try {
      final remoteList = await remote.listConversations(skip: 0, limit: limit);
      await convDao.upsertAll(
        remoteList.map(_conversationToDb).toList(growable: false),
      );
      await convLocal.checkpoint(page: 1, limit: limit);
    } catch (_) {
      // No rompas la UI por errores de bg
    }
  }

  @override
  Future<Conversation> ensureDirectConversation(String otherUserId) async {
    final c = await remote.ensureDirectConversation(otherUserId);
    await convDao.upsertAll([_conversationToDb(c)]);
    return c;
  }

  @override
  Future<String> createThread({
    required String renterId,
    required String hostId,
    required String vehicleId,
    required String bookingId,
    String? initialMessage,
  }) async {
    final id = await remote.createThread(
      renterId: renterId,
      hostId: hostId,
      vehicleId: vehicleId,
      bookingId: bookingId,
      initialMessage: initialMessage,
    );
    // Si luego haces ensureDirect/open por ese id, se cacheará ahí.
    return id;
  }

  // --------------------------
  // Messages (by otherUserId)
  // --------------------------

  @override
  Future<List<MessageModel>> getThread(
    String otherUserId, {
    int skip = 0,
    int limit = 100,
    bool onlyUnread = false,
  }) async {
    // 0) Find (or create) the direct conversation to get its ID
    String? convId;
    try {
      final conv = await remote.ensureDirectConversation(otherUserId);
      convId = conv.conversationId;
      if (convId != null && convId.isNotEmpty) {
        // 1) CACHE-FIRST: try to serve from local immediately
        final cached = await msgLocal.getByConversation(
          conversationId: convId,
          page: (skip ~/ (limit == 0 ? 1 : limit)) + 1,
          limit: limit,
        );
        if (cached.isNotEmpty) {
          // return cached early — UI shows instantly
          // and we'll still refresh from remote below
          // but don't stop here; fall-through to remote to refresh silently
          // If you prefer to strictly “return cached and stop” when offline,
          // add a try/catch around the remote call below and return cached on error.
          // For now: just keep going.
        }
      }
    } catch (_) {
      // If ensureDirectConversation fails, proceed with remote (will still work).
    }

    // 2) REMOTE: always try to refresh from network
    final list = await remote.getThread(
      otherUserId,
      skip: skip,
      limit: limit,
      onlyUnread: onlyUnread,
    );

    // 3) Cache the fresh messages
    if (list.isNotEmpty) {
      await msgDao.upsertAll(list.map(_messageToDb).toList(growable: false));

      final foundConvId = _firstConversationId(list);
      if (foundConvId != null) {
        // checkpoint for paging
        await msgLocal.checkpoint(
          foundConvId,
          page: (skip ~/ (limit == 0 ? 1 : limit)) + 1,
          limit: limit,
        );
      }
    }

    // 4) Return remote result (UI will update)
    return list;
  }

  Future<void> _refreshThreadInBackground({
    required String otherUserId,
    required int limit,
    required bool onlyUnread,
  }) async {
    if (!await Net.isOnline()) return;
    try {
      final list = await remote.getThread(
        otherUserId,
        skip: 0,
        limit: limit,
        onlyUnread: onlyUnread,
      );
      await msgDao.upsertAll(list.map(_messageToDb).toList(growable: false));
      final convId = _firstConversationId(list);
      if (convId != null) {
        await msgLocal.checkpoint(convId, page: 1, limit: limit);
      }
    } catch (_) {
      // silencioso
    }
  }

  @override
  Future<void> markThreadAsRead(String otherUserId) async {
    await remote.markThreadAsRead(otherUserId);

    // Opcional: intenta obtener convId y marca localmente
    try {
      final conv = await remote.ensureDirectConversation(otherUserId);
      final convId = conv.conversationId;
      if (convId != null && convId.isNotEmpty) {
        // si tienes un método en msgLocal/dao para marcar readAt en local:
        // await msgLocal.markThreadRead(convId, readAt: DateTime.now().toUtc());
      }
    } catch (_) {}
  }

  @override
  Future<MessageModel> sendMessage({
    required String receiverId,
    required String content,
    String? conversationId,
    Map<String, dynamic>? meta,
  }) async {
    final msg = await remote.sendMessage(
      receiverId: receiverId,
      content: content,
      conversationId: conversationId,
      meta: meta,
    );

    // Cachear el enviado
    await msgDao.upsertAll([_messageToDb(msg)]);

    // Podrías refrescar lastMessageAt en Conversations si necesitas:
    if (msg.conversationId != null) {
      // No forzamos nada; el server debería actualizar last_message_at en listConversations
    }

    return msg;
  }

  @override
  Future<MessageModel?> getLastMessageInThread(
    String otherUserId, {
    String? onlyReceivedBy,
  }) async {
    // Delegamos a tu implementación actual (ya trae ordenado DESC).
    return remote.getLastMessageInThread(
      otherUserId,
      onlyReceivedBy: onlyReceivedBy,
    );
  }

  // --------------------------
  // Helpers: Model -> Drift Companion
  // --------------------------

  ConversationsCompanion _conversationToDb(Conversation c) {
    // Ajusta los nombres a EXACTAMENTE tus campos de Conversation.
    // Asumo: conversationId, userLowId, userHighId, createdAt, lastMessageAt
    return ConversationsCompanion(
      conversationId: Value(c.conversationId),
      userLowId: Value(c.userLowId),
      userHighId: Value(c.userHighId),
      createdAt: Value(_asDateTime(c.createdAt)),
      lastMessageAt: Value(_asDateTimeOrNull(c.lastMessageAt)),
    );
  }

  MessagesCompanion _messageToDb(MessageModel m) {
    // Ajusta nombres a EXACTAMENTE tus campos de MessageModel.
    // Asumo: messageId, conversationId, senderId, receiverId, content, meta (Map?), createdAt, readAt
    return MessagesCompanion(
      messageId: Value(m.messageId),
      conversationId: Value(m.conversationId),
      senderId: Value(m.senderId),
      receiverId: Value(m.receiverId),
      content: Value(m.content),
      meta: Value(m.meta == null ? null : jsonEncode(m.meta)),
      createdAt: Value(_asDateTime(m.createdAt)),
      readAt: Value(_asDateTimeOrNull(m.readAt)),
      isDeleted: const Value(false),
    );
  }

  String? _firstConversationId(List<MessageModel> list) {
    for (final m in list) {
      if (m.conversationId != null && m.conversationId!.isNotEmpty) {
        return m.conversationId;
      }
    }
    return null;
  }

  DateTime _asDateTime(Object? v) {
    if (v is DateTime) return v.toUtc();
    if (v is String) return DateTime.parse(v).toUtc();
    throw ArgumentError('Invalid DateTime value: $v');
    // (si tus modelos garantizan DateTime, nunca entra aquí)
  }

  DateTime? _asDateTimeOrNull(Object? v) {
    if (v == null) return null;
    if (v is DateTime) return v.toUtc();
    if (v is String) return DateTime.parse(v).toUtc();
    throw ArgumentError('Invalid DateTime? value: $v');
  }
}
