// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vehicle_availability_dao.dart';

// ignore_for_file: type=lint
mixin _$VehicleAvailabilityDaoMixin on DatabaseAccessor<AppDatabase> {
  $VehicleAvailabilityTable get vehicleAvailability =>
      attachedDatabase.vehicleAvailability;
}
