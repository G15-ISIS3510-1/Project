// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bookings_dao.dart';

// ignore_for_file: type=lint
mixin _$BookingsDaoMixin on DatabaseAccessor<AppDatabase> {
  $BookingsTable get bookings => attachedDatabase.bookings;
}
