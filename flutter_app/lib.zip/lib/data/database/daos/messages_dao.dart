import 'package:drift/drift.dart';
import 'package:flutter_app/data/database/tables/messages_table.dart';
import '../app_database.dart';

part 'messages_dao.g.dart';

@DriftAccessor(tables: [Messages])
class MessagesDao extends DatabaseAccessor<AppDatabase>
    with _$MessagesDaoMixin {
  MessagesDao(AppDatabase db) : super(db);

  Future<void> upsertAll(List<MessagesCompanion> rows) async {
    await batch((b) => b.insertAllOnConflictUpdate(messages, rows));
  }

  Future<List<MessagesData>> byConversationPaged({
    required String conversationId,
    int limit = 50,
    int offset = 0,
  }) {
    final q =
        (select(messages)
            ..where(
              (t) =>
                  t.conversationId.equals(conversationId) &
                  t.isDeleted.equals(false),
            )
            ..orderBy([(t) => OrderingTerm.desc(t.createdAt)]))
          ..limit(limit, offset: offset);
    return q.get();
  }

  Future<List<MessagesData>> byThreadPaged({
    required String otherUserId,
    int limit = 50,
    int offset = 0,
  }) {
    final q =
        (select(messages)
            ..where(
              (t) =>
                  ((t.senderId.equals(otherUserId) |
                      t.receiverId.equals(otherUserId)) &
                  t.isDeleted.equals(false)),
            )
            ..orderBy([(t) => OrderingTerm.desc(t.createdAt)]))
          ..limit(limit, offset: offset);
    return q.get();
  }

  Future<void> softDelete(String messageId) async {
    await (update(messages)..where((t) => t.messageId.equals(messageId))).write(
      const MessagesCompanion(isDeleted: Value(true)),
    );
  }
}

extension MessagesPagingX on MessagesDao {
  Future<List<MessagesData>> listByConversationPaged({
    required String conversationId,
    int limit = 50,
    int offset = 0,
  }) {
    final q = select(messages)
      ..where(
        (t) =>
            t.conversationId.equals(conversationId) & t.isDeleted.equals(false),
      )
      ..orderBy([(t) => OrderingTerm.desc(t.createdAt)])
      ..limit(limit, offset: offset);
    return q.get();
  }
}
