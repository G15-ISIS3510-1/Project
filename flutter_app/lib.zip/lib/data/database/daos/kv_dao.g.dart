// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'kv_dao.dart';

// ignore_for_file: type=lint
mixin _$KvDaoMixin on DatabaseAccessor<AppDatabase> {
  $KvsTable get kvs => attachedDatabase.kvs;
}
