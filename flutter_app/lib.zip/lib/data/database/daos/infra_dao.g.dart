// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'infra_dao.dart';

// ignore_for_file: type=lint
mixin _$InfraDaoMixin on DatabaseAccessor<AppDatabase> {
  $SyncStateTable get syncState => attachedDatabase.syncState;
  $PendingOpsTable get pendingOps => attachedDatabase.pendingOps;
}
