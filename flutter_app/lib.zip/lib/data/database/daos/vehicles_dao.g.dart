// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vehicles_dao.dart';

// ignore_for_file: type=lint
mixin _$VehiclesDaoMixin on DatabaseAccessor<AppDatabase> {
  $VehiclesTable get vehicles => attachedDatabase.vehicles;
}
