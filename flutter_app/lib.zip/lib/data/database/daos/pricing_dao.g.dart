// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pricing_dao.dart';

// ignore_for_file: type=lint
mixin _$PricingDaoMixin on DatabaseAccessor<AppDatabase> {
  $PricingsTable get pricings => attachedDatabase.pricings;
}
