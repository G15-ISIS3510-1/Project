class SuggestedPrice {
  final double value;
  final String? reasoning;

  const SuggestedPrice(this.value, this.reasoning);
}
