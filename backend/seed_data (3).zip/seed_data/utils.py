# seed_data/utils.py
from __future__ import annotations

import os
import json
import requests
from typing import Any, Dict, Optional, List

# -------------------------------------------------------------------
# Base URL for hitting your running FastAPI
# -------------------------------------------------------------------
BASE_URL = os.getenv("SEED_BASE_URL", "http://127.0.0.1:8000").rstrip("/")

# Cached admin token. This will get filled either:
#  - by set_admin_token() (called from seed_all after admin login), OR
#  - lazily by logging in with SEED_EMAIL / SEED_PASSWORD if available.
_ADMIN_TOKEN_CACHE: Optional[str] = os.getenv("SEED_ADMIN_TOKEN")


# -------------------------------------------------------------------
# Public hook so seed_all can inject ADMIN_TOKEN after login
# -------------------------------------------------------------------
def set_admin_token(token: Optional[str]) -> None:
    """
    Store the admin bearer token so that any later call that doesn't
    have a per-user token can still authenticate using admin.
    """
    global _ADMIN_TOKEN_CACHE
    if token:
        _ADMIN_TOKEN_CACHE = token


# -------------------------------------------------------------------
# Internal helpers
# -------------------------------------------------------------------
def _raise_with_detail(resp: requests.Response) -> None:
    """
    Print server response detail (JSON if possible) and then raise for status.
    Gives output like:
    [seed][http] POST https://... -> 401 {'detail': 'Token requerido'}
    """
    try:
        detail = resp.json()
    except Exception:
        detail = resp.text
    print(f"[seed][http] {resp.request.method} {resp.url} -> {resp.status_code} {detail!r}")
    resp.raise_for_status()


def _normalize_path(path: str) -> str:
    """
    Build a clean absolute URL under BASE_URL.
    We DO NOT force a trailing slash to avoid redirects that can drop headers.
    """
    return f"{BASE_URL}/{path.lstrip('/')}"


def _login_raw(email: str, password: str) -> str:
    """
    Do a bare login call to /api/auth/login and return the bearer token.
    This does NOT rely on _headers() (avoids recursion).
    """
    url = f"{BASE_URL}/api/auth/login"
    resp = requests.post(
        url,
        headers={"Content-Type": "application/json"},
        json={"email": email, "password": password},
        timeout=30,
    )
    if not resp.ok:
        _raise_with_detail(resp)

    data = resp.json()
    token = data.get("access_token") or data.get("token")
    if not token:
        raise RuntimeError(f"[seed][auth] Login response missing token: {data!r}")
    return token


def _get_admin_token() -> Optional[str]:
    """
    Return a usable admin token for fallback auth.
    Priority:
      1. If set_admin_token() already cached one, use that.
      2. Otherwise, try to log in with SEED_EMAIL / SEED_PASSWORD env vars.
    If neither works, return None.
    """
    global _ADMIN_TOKEN_CACHE
    if _ADMIN_TOKEN_CACHE:
        return _ADMIN_TOKEN_CACHE

    admin_email = os.getenv("SEED_EMAIL")
    admin_password = os.getenv("SEED_PASSWORD")

    if not admin_email or not admin_password:
        # no cached token and no creds = we can't fallback
        return None

    try:
        _ADMIN_TOKEN_CACHE = _login_raw(admin_email, admin_password)
        return _ADMIN_TOKEN_CACHE
    except Exception as e:
        print(f"[seed][auth] WARNING: could not fetch admin token fallback: {e}")
        return None


def _headers(token: Optional[str] = None) -> Dict[str, str]:
    """
    Build headers for any authenticated request.
    - Always send Content-Type: application/json
    - Use the per-user token if provided.
    - Otherwise fall back to admin token (cached/global).
    """
    effective_token = token or _get_admin_token()

    h: Dict[str, str] = {"Content-Type": "application/json"}
    if effective_token:
        h["Authorization"] = f"Bearer {effective_token}"
    return h


# -------------------------------------------------------------------
# Public helpers used by the individual seed_* modules
# -------------------------------------------------------------------
def post_with_auth(path: str, token: Optional[str], payload: Dict[str, Any]) -> Any:
    """
    Authenticated POST to `path`.
    `token` can be the specific user's token OR None.
    We will auto-fallback to admin token if token is None.
    Raises if non-2xx.
    Returns parsed JSON (dict/list).
    """
    url = _normalize_path(path)
    resp = requests.post(
        url,
        headers=_headers(token),
        json=payload,
        timeout=60,
    )
    if not resp.ok:
        _raise_with_detail(resp)

    try:
        return resp.json()
    except ValueError:
        print(f"[seed][http] Non-JSON POST response at {url}: {resp.text!r}")
        raise


def get_with_auth(path: str, token: Optional[str]) -> Any:
    """
    Authenticated GET to `path`.
    Returns parsed JSON (dict or list).
    """
    url = _normalize_path(path)
    resp = requests.get(
        url,
        headers=_headers(token),
        timeout=30,
    )
    if not resp.ok:
        _raise_with_detail(resp)

    try:
        return resp.json()
    except ValueError:
        print(f"[seed][http] Non-JSON GET response at {url}: {resp.text!r}")
        raise


def login(email: Optional[str] = None, password: Optional[str] = None) -> str:
    """
    Convenience login for arbitrary test users.
    Falls back to SEED_EMAIL / SEED_PASSWORD if no explicit creds.
    Returns that user's bearer token.
    """
    email = email or os.getenv("SEED_EMAIL")
    password = password or os.getenv("SEED_PASSWORD")

    if not email or not password:
        raise RuntimeError(
            "SEED_EMAIL/SEED_PASSWORD not set and no credentials provided to login()"
        )

    # Call bare login so we don't recurse into _headers()
    url = f"{BASE_URL}/api/auth/login"
    resp = requests.post(
        url,
        headers={"Content-Type": "application/json"},
        json={"email": email, "password": password},
        timeout=30,
    )

    if not resp.ok:
        _raise_with_detail(resp)

    data = resp.json()
    token = data.get("access_token") or data.get("token")
    if not token:
        raise RuntimeError(f"[seed][auth] Login response missing token: {data!r}")
    return token


def clean_phone(value: str) -> str:
    """Strip everything except digits."""
    return "".join(ch for ch in value if ch.isdigit())


def find_path(preferred: str, fallbacks: List[str]) -> str:
    """
    Ask the API's OpenAPI spec which path actually exists.
    Helps when endpoints might be `/api/x` vs `/api/x/`.
    """
    try:
        spec = requests.get(f"{BASE_URL}/openapi.json", timeout=10).json()
        paths = set(spec.get("paths", {}).keys())

        def variants(p: str) -> List[str]:
            p_norm = "/" + p.lstrip("/")
            return list({p_norm, p_norm.rstrip("/"), p_norm.rstrip("/") + "/"})

        # Try preferred first, then all fallbacks, with/without slash
        candidates: List[str] = []
        candidates.extend(variants(preferred))
        for fb in fallbacks:
            candidates.extend(variants(fb))

        for cand in candidates:
            if cand in paths:
                return cand
    except Exception as e:
        print(f"[seed][openapi] could not load or parse openapi.json: {e}")

    return preferred
